# # JObjectApiResult

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **int** | 业务状态码 | [optional] [default to 200]
**err** | **string** | 错误消息 | [optional] [default to '']
**data** | **array<string,array>** | 业务数据 | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
